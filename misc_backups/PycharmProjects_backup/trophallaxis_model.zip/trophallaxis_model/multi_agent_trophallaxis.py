from collections import namedtuple
from matplotlib import pyplot as plt
import numpy as np
import random
import time
from IPython import display
from itertools import *



class TrophallaxisError(Exception):
    pass

Location = namedtuple("Location", ("x", "y"))


def divide_matrices(dividend, divisor):
    """
    Ignore division by zero.

    Parameters
    ----------
    dividend : Sequence
        The dividend array.
    divisor : Sequence
        The divisor array.

    Returns
    -------
    np.ndarray
        The quotient, with extraneous values set to zero.

    Examples
    --------
    >>> divide_matrices([-1, 0, 1, 6], [0, 0, 0, 4])
    array([0, 0, 0, 1.5])

    References
    ----------
    .. [#] NumPy: Return 0 with devide by zero. StackOverflow.
       http://stackoverflow.com/questions/26248654/numpy-return-0-with-divide-by-zero

    """
    with np.errstate(divide='ignore', invalid='ignore'):
        quotient = np.divide(dividend, divisor)
        quotient[~np.isfinite(quotient)] = 0  # -inf inf NaN
    return quotient


def shrink(data, rows, cols):
    """
    Shrinks array to the number of rows and columns specified by setting each
    element of output array to sum of the absorbed elements from input array.

    Parameters
    ----------
    data : Array
        The original array.
    rows : int
        The number of rows in the output array.
    cols : int
        The number of columns in the output array.

    Returns
    -------
    np.ndarray
        Array of dimensions rows, cols

    References
    ----------
    # https://stackoverflow.com/a/10685869

        """

    return data.reshape(rows, data.shape[0] // rows,
                        cols, data.shape[1] // cols).sum(axis=1).sum(axis=2)


def grow(data, rows, cols):
    """
       Grows array to the number of rows and columns specified by repeating each
       element of input array.

       Parameters
       ----------
       data : Array
           The original array.
       rows : int
           The number of rows in the output array.
       cols : int
           The number of columns in the output array.

       Returns
       -------
       np.ndarray
           Array of dimensions rows, cols

           """

    return data.repeat(rows, axis=0).repeat(cols, axis=1)

'''
Global variables

base_metabolism : int
    The base energy consumption per step of each bot
e_threshold_store : int
    The stored energy threshold that prompts bots to change their task from storing
    energy to exploring the grid for isolated bots and new energy sources.
e_threshold_store : int
    The stored energy threshold that prompts bots to change their task from exploring
    energy to storing energy and aggregating bots around the source of energy.
sense_range : int
    The distance in grid cells around each both that other bots can be detected.
'''


base_metabolism = 1
e_threshold_store = 2
e_threshold_explore = 10
e_threshold_benevolent = 5
sense_range = 1


class Food(object):
    """

        Maps the distribution of food over the grid space.

       Parameters
       ----------
       n_cells_food : int
           The number of cells with individual values that the food map is
           discretised into.
       max_food_per_cell : int
           The maximum value of a food cell.

       Attributes
       ----------
        n_food_cells : int
           The number of cells with individual values that the food map is decretised into.
        map_size : int
            The length of each side of the food map in grid cells.
        max_food_per_cell : int
           The maximum value of a food cell.
        food_map : array
           The distribution of food across the grid space, food cell discretisation.
       """

    def __init__(self, n_food_cells, max_food_per_cell):
        self.n_food_cells = n_food_cells
        self.map_size = int(np.sqrt(self.n_food_cells))
        self.max_food_per_cell = max_food_per_cell

        # creates food grid and subdivides accordingly
        self.food_map = (np.random.randint(0,
                                      self.max_food_per_cell + 1,
                                      self.n_food_cells)
                    .reshape(self.map_size, self.map_size))

    def __repr__(self):
        return "Food({}, {}, {})".format(self.food_map)

    def __str__(self):
        return str(self.food_map)


class Bot(object):
    """
    Robots agents that travel around the grid space, eating the food.

    Parameters
    ----------

    base_metabolism : int
        The base energy consumption per simulation step of each bot
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from storing
        energy to exploring the grid for isolated bots and new energy sources.
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from exploring
        energy to storing energy and aggregating bots around the source of energy.
    sense_range : int
        The distance in grid cells around each both that other bots can be detected within.
    position : tuple
        The x,y coordinates of the bot location on the bot map
    e_cost_per_step : int
        The energy consumed by by the bot for each step of size = one grid space
    e_local : int
        The binary energy value of the grid space on which bot is located
    e_per_cycle : float
        The energy harvested from the ingested energy per cycle.
    e_stored : float
        The cumulative energy from feeding less the energy consumed.
    chain : object
        The chain in which the bot is connected.
    operating_moed : string
        The operating mode the bot is currently in
    sense_kernel : array
        A representation of the area covered by the robot sense range.
    relay_signal : tuple
        The transmitted x,y coordinates of a bot that has found food

    Attributes
    ----------

    base_metabolism : int
        The base energy consumption per simulation step of each bot
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from storing
        energy to exploring the grid for isolated bots and new energy sources.
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from exploring
        energy to storing energy and aggregating bots around the source of energy.
    sense_range : int
        The distance in grid cells around each both that other bots can be detected within.
    position : tuple
        The x,y coordinates of the bot location on the bot map
    e_cost_per_step : int
        The energy consumed by by the bot for each step of size = one grid space
    e_local : int
        The binary energy value of the grid space on which bot is located
    e_per_cycle : float
        The energy harvested from the ingested energy per cycle.
    e_stored : float
        The cumulative energy from feeding less the energy consumed.
    chain : object
        The chain in which the bot is connected.
    operating_moed : string
        The operating mode the bot is currently in
    sense_kernel : array
        A representation of the area covered by the robot sense range.
    relay_signal : tuple
        The transmitted x,y coordinates of a bot that has found food

    """

    bots = []

    sense_kernel = np.zeros((2 * sense_range + 1) ** 2)
    sense_kernel[(len(sense_kernel) // 2)] = 1
    k = np.sqrt(len(sense_kernel))
    sense_kernel = np.reshape(sense_kernel, (k,k))

    # def __init__(self, position, e_cost_per_step = 1):
    def __init__(self, e_cost_per_step=1):

        self.e_threshold_explore = e_threshold_explore
        self.e_threshold_store = e_threshold_store
        self.sense_range = sense_range
        # self.position = position
        self.position = None
        self.e_cost_per_step = e_cost_per_step
        self.e_local = None
        self.e_harvested = 0
        #self.e_per_cycle = None
        self.e_stored = 0
        self.chain = None
        self.operating_mode = "explore"
        self.sense_kernel = None
        self.relay_signal = None
        #self._generate_sense_kernel()

    def _generate_sense_kernel(self):
        """
        Generate a kernel that represents of the area covered by the robot sense range.
        """
        self.sense_kernel = np.zeros((2 * self.sense_range + 1) ** 2)
        self.sense_kernel[(len(self.sense_kernel) // 2)] = 1
        self.sense_kernel = np.reshape(self.sense_kernel, (
        np.sqrt(len(self.sense_kernel)), np.sqrt(len(self.sense_kernel))))

        # sense_kernel = np.zeros((2 * sense_range + 1) ** 2)
        # sense_kernel[(len(sense_kernel) // 2)] = 1
        # sense_kernel = np.reshape(sense_kernel, (
        # np.sqrt(len(sense_kernel)), np.sqrt(len(sense_kernel))))

    def update_e_stored(self):
        """
        Cumulative addition of energy harvested (e_per_cycle) to stored energy
        """
        #self.e_stored += self.e_per_cycle
        self.e_stored = self.e_stored + self.e_local

    # def sense(self, bot_map, search_subject, Y, X):
    # # TODO: combine sense_bots and sense_spaces functions as 1 function that...
    # # returns bots/spaces as list/randomly selected individual
    #     """
    #     Checks if bot has any neighbouring bots/ spaces/ neighbouring recruits
    #     Parameters
    #     ----------
    #     bot_map : array
    #
    #     Returns
    #     -------
    #     Tuple of arrays, one with y and one with x indices of elements that are neighbours of subject type.
    #
    #
    #     """
    #     neighbours = []
    #
    #     # top left hand corner of kernel
    #     i = Y - self.sense_range
    #     j = X - self.sense_range
    #     # length of kernel side
    #     k = sense_kernel.shape[0]
    #
    #     #window = [i:i + k, j:j + k]
    #     #window = slice(i:i + k, j:j + k)
    #
    #     #print(bot_map[i:i + k, j:j + k])
    #
    #     # if search_subject == "bot":
    #     #     window = np.copy(bot_map[i:i + k, j:j + k]) - self.sense_kernel
    #     #     # neighbours = np.nonzero(window) + np.array([[i], [j]])
    #     #     neighbours = np.nonzero(window)
    #     #
    #     # if search_subject == "space":
    #     #     window = np.copy(bot_map[i:i + k, j:j + k])
    #     #     #neighbours = np.where(window < 1) + np.array([[i], [j]])
    #     #     neighbours = np.where(window < 1)
    #     #
    #     # return neighbours
    #
    #     if search_subject == "1":
    #         _ = np.copy(bot_map[i:i + k, j:j + k]) - self.sense_kernel
    #         # neighbours = np.nonzero(window) + np.array([[i], [j]])
    #         #neighbours = np.nonzero(_)
    #         neighbours.argwhere(_ > 0)
    #
    #     if search_subject == "0":
    #         _ = np.copy(bot_map[i:i + k, j:j + k])
    #         # neighbours = np.where(i:i + k, j:j + k < 1) + np.array([[i], [j]])
    #         neighbours = np.argwhere(not _ ) #and np.argwhere(_ ! < 0)
    #
    #     if search_subject == "-1":
    #         _ = np.copy(bot_map[i:i + k, j:j + k])
    #         # neighbours = np.where(i:i + k, j:j + k < 1) + np.array([[i], [j]])
    #         neighbours = np.argwhere(_ < 0)
    #
    #         return neighbours


    #def recruit(self, tail_bot, bot_map):
        # """
        #
        # Parameters
        # ----------
        # self
        # tail_bot
        # bot_map
        #
        # Returns
        # --------
        # A randomly selected explorer bot if there are more than two available in the sense range
        #
        # """
        # recruitables = []
        #
        # # make a copy of the bot map
        # recruit_map = np.copy(bot_map)  # [i:i + 3, j:j + 3]) - kernel
        # # zero out all pioneers as they have already been recruited
        # for pioneer in self.chain.pioneers:
        #     recruit_map[pioneer.position.y][pioneer.position.x] = 0
        #
        # i = tail_bot.position.y - self.sense_range
        # j = tail_bot.position.x - self.sense_range
        # k = self.sense_kernel.shape[0]
        #
        # _window = recruit_map[i:i + k, j:j + k]
        #
        # if (_window).any:
        #
        #     neighbours_local = np.nonzero(_window)
        #
        #     neighbours_global = np.nonzero(_window) + np.array(
        #         [[i], [j]])
        #
        #     for u, v in zip(*neighbours_global):
        #         for fellow_explorer in self.chain.connected_bots:
        #             if fellow_explorer.position == Location(v, u):
        #                 recruitables.append(Location(v, u))
        #
        # if len(recruitables) >= 2:
        #     return random.choice(recruitables)
        #
        # else:
        #     return 0

    # def feed_hungry_bot(self, hungry_bot):
    #     # TODO: include a) how much energy is transferred, b) threshold below which bot will not tranfer energy
    #     # c) efficiency of energy transfer, d) benevolence of fed bot based on e_stored
    #     """
    #     Transfers stored energy from fed bot to hungry bot.
    #     """
    #         # if bot has energy above an arbitrary threshold (4) it will transfer half to hungry bot
    #     if self.e_stored >= 4:
    #         self.e_stored -=2
    #         hungry_bot.e_stored += 2

    def move_towards_fed_bot(self, fed_bot, world):

        """
        Re-orientates bot to attempt to access the food supplying the fed bot.
        If alligned in the x direction, the bot re-orientates to instead align in the y direction.
        If alligned in the y direction, the bot re-orientates to instead align in the x direction.
        If alligned diagonally, either x or y alignment is selected randomly.

        Parameters
        ----------
        fed_bot : object
            The bot which the hungry bot (self) moves towards.
        """
        # select a new position one step from initial position
        if self.position.y == fed_bot.position.y:
            new_position = Location(fed_bot.position.x, np.clip((self.position.y + random.choice([-1,1])) , 1,
                        world.bot_map_size - 2))

        elif self.position.x == fed_bot.position.x:
            new_position = Location(fed_bot.position.x, np.clip((self.position.y + random.choice([-1, 1])) , 1,
                        world.bot_map_size - 2))

        else: # bot.position.y != fed_bot.position.y and bot.position.x != fed_bot.postion.x
            new_position = random.choice([Location(fed_bot.position.x, self.position.y), Location(self.position.x, fed_bot.position.y)])

        #if the cell is unoccupied, move the bot
        if not world.bot_map[new_position.y][new_position.x]:
            'hungry bot moved towards fed bot'
            #print(self.position)
            self.move_bot(world, new_position)
            #print(self.position)

    def move_bot(self, world, new_position):
            world.bot_map[new_position.y][new_position.x]= 1
            world.bot_map[self.position.y][self.position.x] = 0
            self.position = new_position
            self.e_stored -= self.e_cost_per_step

    def random_walk(self, units_moved, world):
        """
        Bot moves with random path in the grid space.

        Parameters
        ----------
        units_moved : int
            The number of units each bot should move.
        """
        #self.units_moved = units_moved

        #for _ in np.arange(units_moved):
        while(self.e_stored):

            #select a new position one step from initial position
            new_position = Location(np.clip(self.position.x + random.randint(-1, 1), 1, world.bot_map_size -2 ),
                                    np.clip(self.position.y + random.randint(-1, 1), 1, world.bot_map_size -2 ))

            # if unoccupied, move to position
            if not world.bot_map[new_position.y][new_position.x]:# == 0.0:
                #print(self.position)
                self.move_bot(world, new_position)
                #print(self.position)
                # if food found, stop walking
                if world.food_map[self.position.y][self.position.x]:
                    self.operating_mode = "store"
                    continue
                #print("moved")

            # if unoccupied, query bot
            else:
                #print("collision, query bot")

                sensed_bots_locations = self.sense_bots(world.bot_map)

                if sensed_bots_locations:

                    for sensed_bot_location in sensed_bots_locations:
                        #print(sensed_bot_location)

                        for other_bot in self.bots:

                            # look up other bot by location
                            if other_bot.position == sensed_bot_location:
                                #print(other_bot.position)

                                # compare difference in e_local
                                if not (self.e_local - other_bot.e_local and self.e_local):
                                    #print("try to connect")
                                    attempt_connect(self, other_bot)

                                if (self.e_local - other_bot.e_local == 1):
                                    #print("feed hungry bot")
                                    self.feed_hungry_bot(other_bot)

                                if (self.e_local - other_bot.e_local == -1):
                                    #print("move towards fed bot")
                                    # if the hungry bot is in a chain, break chain...
                                    if self.chain:
                                        self.chain.remove_bot(self)
                                    # ...then move in direction of fed bot
                                    self.move_towards_fed_bot(other_bot, world)
                continue


    def send_relay_signal(self):
        """
        Sends current position to neighbours in chain.

        """
        for connected_bot in self.chain.connected_bots:
            connected_bot.relay_signal = self.position

        self.relay_signal = None

    def move_towards_relay_signal(relay_signal):
    # TODO: rewrite to move on the heading of the relay signal using all remainig energy, utilise 'move towards fed bot function

        if bot.chain.pioneers:
            self.chain.remove_bot()

        # self.chain.remove_bot(bot)
        # self.move_towards_fed_bot + random walk(units moved)
        pass

    def __repr__(self):
        return "Bot({})".format(self.position)


    def __str__(self):
        return str(self.position)

class Chain(object):
    """
    Describes serially connected bots when in operating mode "store"
    and groups of bots of the same exploration team when in operating mode "explore".

    Parameters
    ----------
    connected_bots : Iterable(Bot)
        All bots in the chain.
    connected_bots_array : array
        The mapped locations of all bots in the chain, presented as an array, numbered low to high to indicate sequence.
    pioneers : list
        Serially connected bots actively exploring.

    Attributes
    ----------
    connected_bots : list
        All bots in the chain.
    connected_bots_array : array
        The mapped locations of all bots in the chain, presented as an array, numbered low to high to indicate sequence.
    pioneers : list
        Serially connected bots actively exploring.

    """
    chains = []
    chain_arrays = []

    def __init__(self, world, *connected_bots):
        self.connected_bots = list(connected_bots)
        self.connected_bots_array = np.array(world.food_map * 0)
        self.pioneers = []

        # assigns the chain id to each bot in the chain, adds the first two bots to the chain array
        chain_array_count = 0
        for _ in self.connected_bots:
            _.chain = self
            chain_array_count +=1
            self.connected_bots_array[_.poistion.y][_.position.x] = chain_array_count

        self.chains.append(self)
        self.chain_arrays.append(self.chain_arrays)

    def add_bot_to_chain(self, bot_index, bot_to_insert):
        """
        Inserts a single bot at the head or tail of a chain

        Parameters
        ----------
        bot_index
        bot_to_insert

        """


        if bot_index == 0:
            self.connected_bots.insert(bot_index, bot_to_insert)
        if bot_index ==-1:
            self.connected_bots.insert(len(self.connected_bots), bot_to_insert)

        bot_to_insert.chain = self

    def add_chain_to_chain(self, bot_index, bot_to_insert, bot_to_insert_index):
        """
        Migrates a chain to the end of a chain indicated by the indices given
        and deletes abandoned chain from list.

        Parameters
        ----------
        bot_index
        bot_to_insert
        bot_to_insert_index

        """

        if (bot_index == bot_to_insert_index):
            bot_to_insert.chain.connected_bots = list(
                reversed(bot_to_insert.chain.connected_bots))

        for _ in bot_to_insert.chain.connected_bots:
            _.chain = self

        #print(self.connected_bots)

        if(bot_index == -1):
            self.connected_bots.extend(bot_to_insert.chain.connected_bots)

        else:#if index = 0
            self.connected_bots[0:0] = bot_to_insert.chain.connected_bots

        #print(self.connected_bots)

        self.chains.remove(bot_to_insert.chain)


    def remove_bot(self, bot):
        """
        Removes a bot from the chain it is in and forms the bots severed from
        the end of the chian into a new chain.

        Parameters
        ----------
        bot

        Returns
        -------

        """

        break_point = self.connected_bots.index(bot)

        # if there are 2 or more bots severed, form then into a new chain
        if len(self.connected_bots[(break_point + 1):]) > 1:
            Chain(*self.connected_bots[(break_point + 1):])
        # otherwise severed bot is single bot
        else:
            for _ in self.connected_bots[(break_point + 1):]:
                _.chain = None

        # if there are 2 or more left in the old chain, stay as chain
        if len(self.connected_bots[:break_point])> 1:
            self.connected_bots = self.connected_bots[:break_point]
        # otherwise remaining bot is single bot
        else:
            self.disconnect_chain()

        # remove bot itself from chain
        bot.chain = None
        #self.connected_bots.remove(bot)

    def disconnect_chain(self):

        for bot in self.connected_bots:
            bot.chain = None
        #self.chains.remove(self) # TODO: fix this line, ValueError: list.remove(x): x not in list

    def __repr__(self):
        return "Chain({})".format(self.connected_bots)

    def __str__(self):
        return str(self.connected_bots)


class World(object):

    """
     Maps the distribution of food over the grid space.

      Parameters
      ----------
      e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from storing
        energy to exploring the grid for isolated bots and new energy sources.
      e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from exploring
        energy to storing energy and aggregating bots around the source of energy.
      sense_range : int
        The distance in grid cells around each both that other bots can be detected within.
      n_bots : int
            The number of bots
      _food : object
            The food distribution across the grid space.
      n_food_cells :
          The number of food cells
      map_size : int
           The length of each side of the food map.
      food_map : array
         The distribution of food across the grid space.
      bot_map : array
          The distribution of bots across the grid space.
      bot_map_size : int
          The length of each side of the bot map in grid units.
      stored_energy_map : array
          The map of cumulative energy stored by each bot.
      bots : list
          All the bots.

      Attributes
      ----------
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from storing
        energy to exploring the grid for isolated bots and new energy sources.
    e_threshold_store : int
        The stored energy threshold that prompts bots to change their task from exploring
        energy to storing energy and aggregating bots around the source of energy.
    sense_range : int
        The distance in grid cells around each both that other bots can be detected within.
      n_bots : int
            The number of bots
      _food : object
            The food distribution across the grid space.
      n_food_cells :
          The number of food cells
      map_size : int
           The length of each side of the food map.
      food_map : array
         The distribution of food across the grid space.
      bot_map : array
          The distribution of bots across the grid space.
      bot_map_size : int
          The length of each side of the bot map in grid units.
      stored_energy_map : array
          The map of cumulative energy stored by each bot.
      bots : list
          All the bots.
      """

    def __init__(self, n_bots, food):
        self.e_threshold_explore = e_threshold_explore
        self.e_threshold_store = e_threshold_store
        self.sense_range = sense_range
        self.n_bots = n_bots
        self._food = food
        self.n_food_cells = self._food.n_food_cells
        self.map_size = self._food.map_size
        self.food_map, self.food_map_size = self._pad_map(self._food.food_map, 1)
        self.stored_energy_map = self.food_map * 0
        self.bot_map = None
        self.bot_map_size = None
        self.stored_energy_map = self.food_map * 0
        self._populate_bot_map()
        self.store_mode_map = np.empty((self.bot_map_size) ** 2, dtype=object).reshape(
            self.bot_map_size, self.bot_map_size)
        self.explore_mode_map = np.empty((self.bot_map_size) ** 2, dtype=object).reshape(
            self.bot_map_size, self.bot_map_size)

    def _pad_map(self, map_to_pad, _border_width):
        """
        Creates a border of width = _border_width around the map as dictated by the sense range

        Parameters
        ----------
        map_to_pad
        _border_width

        Returns
        -------

        """

        _full_map_size = int(self.map_size + 2*_border_width)

        if map_to_pad.dtype == object:
            _full_map = np.empty((_full_map_size) ** 2, dtype=object).reshape(
                _full_map_size, _full_map_size)

        else:
            _full_map = np.zeros((_full_map_size) ** 2).reshape(_full_map_size,
                                                                _full_map_size)

        _full_map[_border_width:(_border_width + self.map_size), _border_width:(_border_width + self.map_size)] = map_to_pad
        return _full_map, _full_map_size

    def _populate_bot_map(self):

        """
        Distributes n_bots start locations randomly over the grid space

        """
        self.bot_map = np.empty(self.n_food_cells, dtype=object)

        for i in range(self.n_bots):
            self.bot_map[i] = Bot()

        np.random.shuffle(self.bot_map)
        self.bot_map = np.reshape(self.bot_map, (self.map_size, self.map_size))
        self.bot_map, self.bot_map_size = self._pad_map(self.bot_map, self.sense_range)
        y, x = np.where(self.bot_map)

        for Y, X in zip(y, x):
            self.bot_map[Y, X].position = Location(X, Y)
            ##print(self.bot_map[Y, X].position)

            # STORE ALL BOTS IN A LIST
        # for i in range(self.n_bots):
        #     bot = Bot(bot_initial_positions[i])
        #     Bot.bots.append(bot)

    def feed(self):
        """
        Decreases food map by 1 unit in every grid cell occupied by a bot
        Produces _e_from_food_map of all energy accumulated from feeding
        Updates the stored energy map with the energy from feeding TODO: plot at the end with all consumed energy condsidered: base metabolic energy expenditure etc

        """
        np.clip(self.food_map - np.array(self.bot_map, dtype=bool)*1,
                0, float("inf"), self.food_map)

        _e_from_food_map = np.clip(divide_matrices(self.food_map,
                np.array(self.bot_map, dtype=bool)*1), 0, 1)

        self.stored_energy_map = self.stored_energy_map + _e_from_food_map

        # update e_local of all bots

        # self.stored_energy_map = np.clip(
        #     (self.stored_energy_map
        #      + _e_from_food_map)
        #     # - np.multiply(self.bot_map, base_metabolism))
        #     , 0, float("inf"), self.stored_energy_map)
        #
        # for bot in Bot.bots:
        #     bot.e_local = _e_from_food_map[bot.position.y][bot.position.x]
        #     # TODO: a) why can't e_harvested be added to e_stored?! b) write e_harvested as a function of e_local
        #     bot.harvested = _e_per_cycle_map[bot.position.y][bot.position.x]
        #     bot.e_stored += bot.e_local
        #
        # # TODO: make this a function as it is called at both start and end
        # # plots food map and bot map, bots colour indicates stored energy
        # plt.matshow(self.food_map, cmap='Greens', vmin = 0, vmax = self._food.max_food_per_cell)
        # y, x = np.where(self.bot_map)
        # plt.scatter(x, y, 40, c = self.stored_energy_map[y, x] , cmap = "Reds", vmin = 0, vmax = e_threshold_explore)
        # plt.show()

    def feed_hungry_bot(fed, hungry):

        food_transferred = int(self.stored_energy_map[fed[1].fed[0]]/2) # TODO: what works better, do donate as much as possible or give a small share to donate to many bots
        self.stored_energy_map[fed[1].fed[0]] -= food_transferred #TODO: efficeincy of transfer
        self.stored_energy_map[hungry[1], hungry[0]] = +=food_transferred

def store(bot, world):
    #print("STORE MODE")
    # are there bots within sense range? if true...
    sensed_bots_locations = bot.sense_bots(world.bot_map)
    #print("sensed bots", sensed_bots_locations)

    if sensed_bots_locations:

        for sensed_bot_location in sensed_bots_locations:
            #print(sensed_bot_location)

            for other_bot in bot.bots:

                # look up other bot by location
                if other_bot.position == sensed_bot_location:
                    #print(other_bot.position)

                    # compare difference in e_local
                    if not (bot.e_local - other_bot.e_local and bot.e_local):
                        #print("try to connect")
                        attempt_connect(bot, other_bot)

                    if (bot.e_local - other_bot.e_local == 1):
                        #print("feed hungry bot")
                        bot.feed_hungry_bot(other_bot)

                    if (bot.e_local - other_bot.e_local == -1):
                        #print("move towards fed bot")
                        # if the hungry bot is in a chain, break chain...
                        if bot.chain:
                            bot.chain.remove_bot(bot)
                        # ...then move in direction of fed bot
                        bot.move_towards_fed_bot(other_bot, world)

    else:
        # if bot is hungry go for random walk using stored energy
        #print("no bots sensed, random walk if hungry")
        if bot.e_local == 0:
            #print("hungry --> random walk")
            bot.random_walk(bot.e_stored, world)

def attempt_connect(bot, other_bot):
    if other_bot.operating_mode == "store" and bot.operating_mode == "store":
        #print("good to go!")

        # if bot is single...
        if bot.chain == None:
            #print("single bot")

            # ...and other bot is single and not in explore mode
            if other_bot.chain == None:
                #print("and other bot single")
                Chain(bot, other_bot)
                #print(Chain.chains[-1].connected_bots)

                # ...or other bot is in chain and not in explore mode
            elif other_bot.chain:
                #print("and other bot chain")
                # is other bot head or tail? i.e. can it connect?
                _bot_index = other_bot.chain.connected_bots.index(
                    other_bot)

                if _bot_index == 0 or _bot_index  == -1:
                    other_bot.chain.add_bot_to_chain(_bot_index, bot)

                else:
                    #print("not head or tail")
                    pass

    # if bot is in chain...
    elif bot.chain:
        #print("bot in chain")

        # can bot connect i.e. head or tail?
        _bot_index = bot.chain.connected_bots.index(bot)

        if _bot_index == 0 or _bot_index  == -1:

            # ...and other bot is in chain and it is a different chain from bot
            if other_bot.chain and other_bot.chain != bot.chain:
                #print("other bot in different chain")

                # can other bot connect i.e. head or tail?
                _other_bot_index = other_bot.chain.connected_bots.index(
                    other_bot)

                if _other_bot_index == 0 or _other_bot_index == -1:
                    #print("both bots head or tail - connect!")
                    bot.chain.add_chain_to_chain(_bot_index,
                                               other_bot, _other_bot_index)

def explore(bot,world):
    #print("EXPLORE MODE")

    if bot.chain:

        if bot.relay_signal:
            bot.move_towards_relay_signal()

            # if a leader has not been selected yet bot is the leader
            if bot.chain.pioneers == False or\
                    (bot.chain.pioneers and bot.position == bot.chain.pioneers[0].position and
                             _.e_stored for pioneer in bot.chain.pioneers):

            # if free space exists at the head...:
                available_location = bot.sense_space(world.bot_map)
                if available_location:

                    if not bot.chain.pioneers:
                        tail_bot = bot
                    else:
                        tail_bot = bot.chain.pioneers[-1]

                    # and bots are recruitable at the tail...
                    available_recruit = bot.recruit(tail_bot, world.bot_map)
                    if available_recruit:

                        # go exploring!
                        # extend pioneer exploration by one place in a random direction
                        world.bot_map[available_location.y][available_location.x] = 1
                        # absorb one explorer into pioneer chain
                        world.bot_map[available_recruit.y][available_recruit.x] = 0

                        for new_recruit in bot.chain.connected_bots:
                            if new_recruit.position == available_recruit:
                                bot.chain.pioneers.append(new_recruit)

                        for pioneer_new, pioneer_old in zip(reversed(bot.chain.pioneers[1:]), reversed(bot.chain.pioneers[:-1])):
                            pioneer_new.position = pioneer_old.position
                            pioneer_new.e_stored -= bot.e_cost_per_step

                        bot.chain.pioneers[0].position = available_location
                        bot.chain.pioneers[0].e_stored -= bot.e_cost_per_step

                # evaluate (new) surroundings:
                # if food found leave chain and send relay singal to others:
                if bot.e_local == 1:

                    bot.send_relay_signal()
                    bot.operating_mode = "store"
                    if bot.chain.pioneers:
                        bot.chain.pioneers = []
                        #bot.chain.pioneers.remove(bot.chain.pioneers[0])
                    bot.chain.remove_bot(bot)

                # if no food found look for bots
                else:
                    # are there new bots within sense range?
                    sensed_bots_locations = bot.sense_bots(world.bot_map)
                    #print("sensed bots", sensed_bots_locations)

                    if sensed_bots_locations:

                        for sensed_bot_location in sensed_bots_locations:

                            for other_bot in bot.bots:
                                #print(other_bot.position)

                                # look up other bot by location
                                if other_bot.position == sensed_bot_location:

                                    # compare output signals of two bots:
                                    # if the other bot is hungry, feed it
                                    if (bot.e_local - other_bot.e_local == 0):
                                        #print("feed hungry bot")
                                        bot.feed_hungry_bot(
                                            other_bot)

                                    # if the other bot is full, and bot is head of send relay message, abandon chain, move towards food
                                    elif (bot.e_local - other_bot.e_local and bot.e_local == -1):
                                        #print("send relay message to neighbour bots and move towards bot with food")
                                        bot.send_relay_signal()
                                        # split from chain and move towards fed bot
                                        bot.chain.remove_bot(bot)
                                        bot.chain.pioneers.remove(bot.chain.pioneers[0])
                                        bot.move_towards_fed_bot(other_bot, world)


            # if a leader has been identified but it is not bot...        # are there new bots within sense range?
            sensed_bots_locations = bot.sense_bots(world.bot_map)
            #print("sensed bots", sensed_bots_locations)

            if sensed_bots_locations:

                for sensed_bot_location in sensed_bots_locations:

                    for other_bot in bot.bots:
                        #print(
                            #other_bot.position)

                        # look up other bot by location
                        if other_bot.position == sensed_bot_location:

                            # compare output signals of two bots:
                            # if the other bot is hungry, feed it
                            if (bot.e_local - other_bot.e_local and bot.e_local == 0):
                                #print(
                                    #"feed hungry bot")
                                bot.feed_hungry_bot(
                                    other_bot)
                            #else:
                                #print("no sensed bots")
    else:
        bot.random_walk(bot.e_stored, world)



def sense(map, search_subject, Y, X):
    # TODO: combine sense_bots and sense_spaces functions as 1 function that...
    # returns bots/spaces as list/randomly selected individual
        """
        Checks if bot has any neighbouring bots/ spaces/ neighbouring recruits
        Parameters
        ----------
        bot_map : array

        Returns
        -------
        Tuple of arrays, one with y and one with x indices of elements that are neighbours of subject type.


        """

def sense(bot_map, search_subject, Y, X):
    neighbours = []

    # top left hand corner of kernel
    i = Y - sense_range
    j = X - sense_range
    # length of kernel side
    #k = Bot.sense_kernel.shape[0]
    k = Bot.k

    #bot_map = np.array(np.copy(bot_map), dtype = bool)*1

    if search_subject == "bot":
        _ = np.copy(bot_map[i:i + k, j:j + k]) - Bot.sense_kernel
        #print(_)
        neighbours = np.argwhere(_ > 0)

    if search_subject == "space":
        _ = bot_map[i:i + k, j:j + k]
        #print(_)
        neighbours = np.argwhere(_ == False)

    if search_subject == "0":
        _ = bot_map[i:i + k, j:j + k]
        print(_)
        neighbours = np.argwhere( _ == False)

    if search_subject == "1":
        _ = bot_map[i:i + k, j:j + k]
        print(_)
        neighbours = np.argwhere( _ > 0)

    if search_subject == "-1":
        _ = bot_map[i:i + k, j:j + k]
        print(_)
        neighbours = np.argwhere(_ < 0)

    return neighbours




def main():

    food_map = Food(100, 30)
    world = World(10, food_map)
    world.feed()

    # loop until: a) all bots incapacitated by hunger (first condition)
    #          OR b) all food removed from grid space
    count = 0
    while(count==0):
        count +=1
    #while (np.any(world.stored_energy_map) and np.any(world.food_map)):
        time.sleep(0.05)
        world.feed()
    #     #dummy connect bots : single
    #     # connect_bots = random.sample(range(0, len(Bot.bots) - 1), 4)
    #     # Chain(Bot.bots[connect_bots[0]],
    #     #                     Bot.bots[connect_bots[1]])
    #     ##print(Chain.chains[0].connected_bots[0])
    #     #Chain.chains[0].connected_bots[0].send_relay_signal()
    #     #Chain.chains[0].disconnect_chain()
    #
    #     # call bots in random order
    #     np.random.shuffle(Bot.bots)
    #     for bot in Bot.bots:
    #
    #         # bots with stored energy do computation
    #         if bot.e_stored:

        # add any new bots to those those exploring and those storing
        y, x = np.where(world.stored_energy_map <= e_threshold_store) and np.where(world.stored_energy_map)
        for Y, X in zip(y, x):
            world.store_mode_map[Y, X] = world.bot_map[Y, X]
            world.explore_mode_map[Y, X] = None

        y, x = np.where(world.stored_energy_map >= e_threshold_explore)
        for Y, X in zip(y, x):
            world.explore_mode_map[Y, X] = world.bot_map[Y, X]
            world.store_mode_map[Y, X] = None

        # starving bots with 0 stored energy are expluded as they are incapacitated
        y, x = np.where(world.bot_map) and np.where(world.stored_energy_map == 0)
        for Y, X in zip(y, x):
            world.explore_mode_map[Y, X] = None
            world.store_mode_map[Y, X] = None

        #store mode operations
        # TODO: call bots in random order
        y, x = np.nonzero(world.store_mode_map)
        for Y, X in zip(y, x):
            #time.sleep(1)

            # if store bot does not have neighbours...
            neighbours = sense(np.array(world.bot_map, dtype=bool)*1 , "bot", Y, X)
            if not neighbours.any():
                print("no neighbours")

                # if there is no local energy, move somewhere new....
                if not world.food_map[Y,X]:
                    Bot.random_walk(world.stored_energy_map[Y,X], world)


            # if store bot does have neighbours...
            else:
                print("neighbours",neighbours)
                print(neighbours[0])
                # # create a temporary map showing ej - ei
                temp_map = np.array(world.food_map, dtype=bool)*1 - bool(world.food_map[Y, X])*1
                print(temp_map)

                friends = sense(temp_map, "1", Y, X)
                #TODO: better way to compare two arrays and return items in both
                for f in friends:
                    for n in neighbours:
                        if f[0] == n[0] and f[1] == n[1], and world.stored_energy_map[Y,X] > e_threshold_benevolent:
                            print("feed_hungry_bot", n)
                            world.feed_hungry_bot()


                            # stored energy at hungry bot.location goes down
                            # stored energy at fed bot.location goes up

                friends = sense(temp_map, "-1", Y, X)
                # TODO: better way to compare two arrays and return items in both
                for f in friends:
                    for n in neighbours:
                        if f[0] == n[0] and f[1] == n[1]:
                            print("yay", n)

                friends = sense(temp_map, "0", Y, X)
                # TODO: better way to compare two arrays and return items in both
                for f in friends:
                    for n in neighbours:
                        if f[0] == n[0] and f[1] == n[1]:
                            print("yay",f,n)



               # np.where 0 --> random walk
                # np.where 1 --> try to connect
                #
                # for y, x in zip(neighbours_y, neighbours_x):



        # for Y, X in zip(y, x):
        #     self.bot_map[Y, X].position = Location(X, Y)
        #     #print(self.bot_map[Y, X].position)



        #

        #world.bots_store_mode

    #
    #             # either bot behaviour change threshold reached?
    #             if bot.e_stored >= world.e_threshold_explore:
    #             #if bot.chain and (bot.e_stored >= world.e_threshold_explore):
    #                 bot.operating_mode = "explore"
    #                 if bot.chain:
    #                     for connected_bot in bot.chain.connected_bots:
    #                         connected_bot.operating_mode = "explore"
    #
    #             if bot.e_stored <= world.e_threshold_store:
    #                 bot.operating_mode = "store"
    #                 # return to operation as individual
    #                 if bot.chain:
    #                     bot.chain.remove_bot(bot)
    #
    #             if bot.operating_mode == "explore":
    #                 #print("explore")
    #                 explore(bot, world)
    #
    #             if bot.operating_mode == "store":
    #                 #print("store")
    #                 store(bot, world)
    #
    if np.any(world.stored_energy_map):
        print("all food eaten")
        print(world.food_map)

    elif np.any(world.food_map):
        print("all bots dead")
        print(world.stored_energy_map)

if __name__ == '__main__':
    main()



from multi_agent_trophallaxis import Food
from multi_agent_trophallaxis import World
from multi_agent_trophallaxis import Bot
print(Bot)
import numpy as np
import random


class Test_random_walk(object):
    """
    Tests for a robot performing a random walk using a quantity of input energy.

    - Are coordinates unique? Yes

    -Are bots within the same chain as the moving bot still within one grid unit of one another?:
    i.e. does the whole chain move? (this may cause prev. test to fail.) Yes

    - Is the visual map updated and plotted?

    """
    #def set_up(self): # TODO: setup statement that means setup does not need repeating each test


    def test_number_of_bots_on_map(self):
        # test that number of bots remians equal before and after walk
        units_moved = 3

        self.food_map = Food(25, 10, 4)
        self.world = World(10, self.food_map)
        self.world.feed()
        self.bot_map_pre_walk = np.copy(self.world.bot_map)

        # choose random bot to test
        Bot.bots[random.randint(0, len(Bot.bots) - 1)].random_walk(units_moved,
                                                                   self.world.bot_map,
                                                                   self.world.bot_map_size)

        assert (np.count_nonzero(self.bot_map_pre_walk) == np.count_nonzero(
            self.world.bot_map))


    # def test_bot_map_move(self):
    #     # test that the map changes
    #
    #     units_moved = 3
    #
    #     self.food_map = Food(25, 10, 4)
    #     self.world = World(10, self.food_map)
    #     self.world.feed()
    #     self.bot_map_pre_walk = np.copy(self.world.bot_map)
    #
    #     Bot.bots[random.randint(0,len(Bot.bots)-1)].random_walk(units_moved, self.world.bot_map, self.world.bot_map_size)
    #
    #     assert (np.array_equal(self.bot_map_pre_walk, self.world.bot_map) == False)


        # #test that the map changes if step!=0
        # if (Bot.bots[random.randint(0, len(Bot.bots) - 1)].random_walk(
        #         units_moved,
        #         self.world.bot_map,
        #         self.world.bot_map_size) == True):
        #
        #     assert(np.array_equal(self.bot_map_pre_walk, self.world.bot_map)==False)
        #
        # # test that the map does not change if step==0
        # if (Bot.bots[random.randint(0, len(Bot.bots) - 1)].random_walk(
        #         units_moved,
        #         self.world.bot_map,
        #         self.world.bot_map_size) == False):
        #
        #     assert (np.array_equal(self.bot_map_pre_walk, self.world.bot_map) == True)

# class Test_random_walk_(object):
#
#     def test_unique_bot_location(self):
#         # test that each bot has unique location
#         units_moved = 2
#
#         self.food_map = Food(25, 10, 4)
#         self.world = World(10, self.food_map)
#         self.world.feed()
#         self.bot_map_pre_walk = np.copy(self.world.bot_map)
#
#         # choose random bot to test
#         Bot.bots[random.randint(0, len(Bot.bots) - 1)].random_walk(units_moved,
#                                                                    self.world.bot_map,
#                                                                    self.world.bot_map_size)
#         d = {}
#         for bot in Bot.bots:
#             d[str(bot.position)] = bot.position
#         assert (len(d) == len(Bot.bots))







#class Test_break_chain(object):
    """
    Tests for a connection to a robot being broken so it is not connected to any chain.
    - Bot location does not appear in any chain list of bots. Yes.
    - Bot energy re-distributed. Yes.
    - (Newly single bot performs random walk function)

    """

# class Test_feed_hungry_bot(object):
    """
    Tests for hungry bot being fed by fed bots within sense range.
    - Is stored energy of chain reduced?
    - Is the visual map updated to show the bot as fed and plotted?
    """

# class Test_make_chain(object):
    """
    Tests for connection to a robot being formed.
    -

    """


# class Test_move_to_make_chin(object):
    """
    Tests for robots moving to connect.
    Similar to random walk
    -Does the map change? Yes
    -Does the number of bots on the map change? No
    - Are the bot coordinates unique. Yes
    - Is the visual map updated and plotted?
    """



from collections import namedtuple
from multi_agent_trophallaxis import Food
from multi_agent_trophallaxis import World
from multi_agent_trophallaxis import Bot
from multi_agent_trophallaxis import Chain
print(Bot)
import numpy as np
import random
import unittest

Location = namedtuple("Location", ("x", "y"))


food_map = Food(25, 10)
world = World(15, food_map)#, 10, 2)
world.feed()


def test_random_walk():

# Test that the number of bots on the bots map remains the same after a bot has moved to try and relocate to food.
# Test that the number of bots in the bots list remains the same after a bot has moved to try and relocate to food.
# Test that there are no bots in the border.
# Test that each bot in the bots list has a unique position

    units_moved = 10

    # Copy the bot_map
    bot_map_pre_walk = np.copy(world.bot_map)

    # move a random walk by n units
    random.choice(Bot.bots).random_walk(units_moved, world)

    # Test the number of bots remains the same
    assert (np.count_nonzero(bot_map_pre_walk) == np.count_nonzero(
        world.bot_map))

    # Test that each bot in the bots list has a unique position
    d = {}
    for bot in Bot.bots:
        d[str(bot.position)] = bot.position
    assert (len(d) == len(Bot.bots))
    #
    # Test there are no bots in the padding
    assert not any(world.bot_map[0]) and not any(world.bot_map[world.bot_map_size-1]) and not any(world.bot_map[:,0]) and not any(world.bot_map[:,world.bot_map_size-1])

def test_single_bot_add_length_and_location():

    # indices of end of chain at which to add bot
    _chain_location = -1
    #_chain_location = 0


    #chain = random.choice(Chain.chains)
    #chain = Chain(*random.sample(Bot.bots, random.randint(2, len(Bot.bots)-1)))
    bot_sample = random.sample(Bot.bots, random.randint(3, len(Bot.bots)-1))
    bot = bot_sample[0]
    chain = Chain(*bot_sample[1:])

    #bot = random.choice(Bot.bots)

    chain.add_bot_to_chain(_chain_location, bot)

    assert chain.connected_bots[_chain_location] == bot and start_length == end_length -1

def test_remove_bot_from_chain():

# Test the number of chains increases by one
# Test number of bots is the conserved
# Test each chain contains unique set of bots
# Test each chain contains unique set of bots
# Test individual bot does not appear in either set of bots

    chain = Chain(*(random.sample(Bot.bots, random.randint(2, len(Bot.bots) - 1))))
    bot = random.choice(chain.connected_bots)
    number_of_chains_start = len(Chain.chains)
    number_of_bots_start = len(chain.connected_bots)

    chain.remove_bot(bot)

    number_of_chains_end = len(Chain.chains)
    number_of_bots_end = len(chain.connected_bots) + len(Chain.chains[-1].connected_bots) + 1

    # Test each chain contains unique set of bots
    #assert bool(set(chain.connected_bots) & set(Chain.chains[-1].connected_bots)) == False

    # Test each chain contains unique set of bots
    # assert bool(set(chain.connected_bots) & set(Chain.chains[-1].connected_bots)) == False

    # TODO: this keeps failing
    # Test individual bot does not appear in either set of bots
    #assert bool(bot in chain.connected_bots) == False
    #assert bool(bot in Chain.chains[-1].connected_bots) == False


def test_disperse_chain():

# Test the number of chains decreases by one

    chain = Chain(*(random.sample(Bot.bots, random.randint(2, len(Bot.bots) - 1))))
    number_of_chains_start = len(Chain.chains)

    chain.disconnect_chain()

    number_of_chains_end = len(Chain.chains)

    assert number_of_chains_start == number_of_chains_end + 1

def test_move_towards_fed_bot():

# Test that the number of bots on the bots map remains the same after a bot has moved to try and relocate to food.
# Test that the number of bots in the bots list remains the same after a bot has moved to try and relocate to food.
# Test that there are no bots in the border.
# Test that each bot in the bots list has a unique position

    # choose a bot
    bot = random.choice(Bot.bots)

    # add a neighbour bot
    neighbour_position = Location(np.clip((bot.position.x + random.randint(-1, 1)),1, world.bot_map_size-2),
                                     np.clip((bot.position.y + random.randint(-1, 1)),1, world.bot_map_size-2))

    neighbour_bot = Bot(neighbour_position)#, world.e_threshold_explore, world.e_threshold_store)

    world.bot_map[neighbour_position.y, neighbour_position.x] = 1

    start_bots_on_bot_map = len(np.nonzero(world.bot_map))

    # move bot
    bot.move_towards_fed_bot(neighbour_bot, world)

    end_bots_on_bot_map = len(np.nonzero(world.bot_map))

    # Test number of bots on bots map remains the same
    #assert start_bots_on_bot_map == end_bots_on_bot_map

    # Test there are no bots in the padding
    #assert not any(world.bot_map[0]) and not any(world.bot_map[world.bot_map_size-1]) and not any(world.bot_map[:,0]) and not any(world.bot_map[:,world.bot_map_size-1])

    # Test each bot position is unique
    e = {}
    for bot in Bot.bots:
        e[str(bot.position)] = bot.position
    assert (len(e) == len(Bot.bots))









from collections import namedtuple
import itertools

import numpy as np
import time




class TrophallaxisError(Exception):
    pass


Location = namedtuple("Location", ("x", "y"))


def shrink(data, rows, cols):
    # https://stackoverflow.com/a/10685869
    return data.reshape(rows, data.shape[0] // rows,
                        cols, data.shape[1] // cols).sum(axis=1).sum(axis=2)

def grow(data, rows, cols):
    return data.repeat(rows, axis=0).repeat(cols, axis=1)


class World(object):
    """
    Parameters
    ----------
    n_bots : int
        The number of bots
    max_bots_per_cell : int
        The maximum number of bots that can be situated on a food cell.
        Must be integer square
    n_cells_food : int
        The number of cells with individual values that the food map is decretised into.
    max_food_per_cell : int
        The maximum value of a food cell.

    Attributes
    ----------


    max_bots_per_cell : int
        The maximum number of bots that can be situated on a food cell.
        Must be integer square
    n_cells_food : int
        The number of cells with individual values that the food map is decretised into.
    max_food_per_cell : int
        The maximum value of a food cell.
    foood_cell_size : int
        The length of each side of a food cell in grid units.
    n_cells_total : int
        The total number of cells that the grid space is dicretised into.
    connected_bots : list
        The chains of bots which are configured in series.
    fed_bot_map : array
        The bots that are fed in the current cycle.
    food_map_size : int
        The length of each side of the food map in food cells.
    bot_map_size : int
        The length of each side of the bot map in grid units.
    food_map : array
        The distribution of food across the grid space, food cell discretisation.
    bot_map : array
        The distribution of bots across the grid space, grid unit discretisation.
    coarse_bot_map : array
        The bot map represented in food cell discretisation.
    local_energy : int
        The energy denisty of the bot location. Either 1 or 0



    """




    def __init__(self, n_bots, max_bots_per_cell, n_cells_food, max_food_per_cell):
        self.count = 0
        self.n_bots = n_bots
        self.max_bots_per_cell = max_bots_per_cell
        self.n_cells_food = n_cells_food
        self.max_food_per_cell = max_food_per_cell
        self.food_cell_size = int(np.sqrt(self.max_bots_per_cell))
        self.n_cells_total = self.n_cells_food * self.max_bots_per_cell
        self.connected_bots = []
        self.fed_bot_map = None

        self.food_map_size = int(np.sqrt(self.n_cells_food))
        self.bot_map_size = self.food_map_size * self.food_cell_size

        # creates food grid and subdivides accordingly
        self.food_map = (np.random.randint(0,
                                           self.max_food_per_cell + 1,
                                           self.n_cells_food)
                         .reshape(self.food_map_size, self.food_map_size))

        # distributes N_BOTS randomly over the grid space
        self.bot_map = np.zeros(self.n_cells_total)
        self.bot_map[:n_bots] = 1
        np.random.shuffle(self.bot_map)
        self.bot_map = np.reshape(self.bot_map,
                                  (self.bot_map_size, self.bot_map_size))

    # reduces bot map resolution to scale of food map
    @property
    def coarse_bot_map(self):
        return shrink(self.bot_map, *self.food_map.shape)

    @property
    def fine_food_map(self):
        return grow(self.food_map, self.food_cell_size, self.food_cell_size)



    def feed(self):
        # Reduces value of each food cell by number of bots that occupy cell, lower bound zero.
        np.clip(self.food_map - self.coarse_bot_map,
                0, float("inf"),
                self.food_map)

    def read_local_energy(self):
        self.local_energy = np.multiply(self.fine_food_map, self.bot_map)
        #self.local_energy = np.multiply(self.map, self.coarse_bot_map)
        self.fed_bot_map = self.local_energy > 0
        print(self.bot_map)
        print(self.local_energy)

    def chain_energy(self):
        self.bot_address = [Location(i, j) for i, j in
                            zip(np.nonzero(self.local_energy)[0],
                                np.nonzero(self.local_energy)[1])]
        #print(self.bot_address)

        #print(self.bot_map, *self.map.shape)
        #print(shrink(self.bot_map, *self.map.shape))
        #print(*self.map.shape)


        # for (i,j) in  zip(np.nonzero(self.fed_bot_map)[0], np.nonzero(self.bot_map)[1]):
        #     print((i, j) in self.connected_bots)

def main():
    world = World(10, 4, 25, 30)
    world.feed()
    world.read_local_energy()
    world.chain_energy()

    # loop until: a) all bots incapacitated by hunger (first condition)
    #          OR b) all food removed from grid space
    # while (np.any(world.fed_bot_map) and np.any(world.map)):
    #     world.count = world.count + 1
    #     world.feed()
    #     world.read_local_energy()
    #     print(world.map)
    #     time.sleep(2)

    #print(world.count)

if __name__ == "__main__":
    main()

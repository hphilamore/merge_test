from collections import namedtuple
import itertools
import random


import matplotlib.pyplot as plt
import numpy as np


Location = namedtuple("Location", ("x", "y"))


class TrophallaxisError(Exception):
    pass


class Food(object):
    """
    Distributes a cells of varying food energy value across a gridspace of width
    by height.

    Parameters
    ----------
    width : int
        Width of grid space.
    height : int
        Height of grid space.
    empty_ratio : float
        The ratio of empty grid cells to total number of grid cells.
    n_iterations : int
        Number of iterations to run.
    n_food_vals : int
        Number of different energy values a cell on the grid can be initialised
        with.
    n_bots_per_cell : Optional[int]
        Number of bots that each food cell can accommodate. Default is 4.

    Attributes
    ----------
    width : int
        Width of grid space.
    height : int
        Height of grid space.
    empty_ratio : float
        The ratio of empty grid cells to total number of grid cells.
    n_iterations : int
        Number of iterations to run.
    n_food_vals : int
        Number of different energy values a cell on the grid can be initialised
        with.
    n_bots_per_cell : int
        Number of bots that each food cell can accommodate. Must be a square.
    cell_side_length: int
        Side length of each square food cell.
    n_cells : int
        The total number of cells.
    agents : dict((int, int): race)
        A mapping of cell address and food values.

    """
    def __init__(self, width, height, empty_ratio, n_iterations, n_food_vals,
                 n_bots_per_cell=4):
        if int(np.sqrt(n_bots_per_cell)) != np.sqrt(n_bots_per_cell):
            raise TrophallaxisError(
                "n_bots_per_cell should be an integer square.")

        self.width = width
        self.height = height
        self.empty_ratio = empty_ratio
        self.n_iterations = n_iterations
        self.n_food_vals = n_food_vals
        self.n_bots_per_cell = n_bots_per_cell
        self.cell_side_length = int(np.sqrt(self.n_bots_per_cell))
        self.n_cells = self.width * self.height // self.n_bots_per_cell
        self.empty_cells = []
        self.agents = {}

    def populate(self):
        """
        Populate each grid , and updates `agents`.

        """
        all_cells = [Location(*i) for i in itertools.product(
            range(self.width)[::self.cell_side_length],
            range(self.height)[::self.cell_side_length])]

        random.shuffle(all_cells)
        # TODO: Change distribution to be more environmentally realistic.
        n_empty = int(self.empty_ratio * len(all_cells))
        self.empty_cells = all_cells[:n_empty]
        food_cells = all_cells[n_empty:]
        # distribute n_food_vals in equal proportions across the cells not
        # defined as empty
        food_vals = {i: list(food_cells[i::self.n_food_vals])
                     for i in range(self.n_food_vals)}

        # create agents assigning each a cell address and food value
        for i in range(self.n_food_vals):
            self.agents.update(dict(zip(food_vals[i], [i] * len(food_vals[i]))))
        self.n_cells = len(all_cells)
        #print(self.agents)

    def plot(self, title, filename):
        """
        Plot a map of the food distribution. Shading scales with amount of food
        present on cell. White squares have no food on them.

        Parameters
        ----------
        title : str
            The title of the plot.
        filename : str
            The location in which the plot will be saved.

        """
        # number of pixels between points: use to set marker size to display
        # grid
        for agent in self.agents:
            # Coordinates that describe each food cell location are plotted at
            # the midpoint of the food cell. The midpoint is shifted by half a
            # cell width to accommodate bots on plot.
            plt.scatter(agent.x + 0.5*self.cell_side_length,
                        agent.y + 0.5*self.cell_side_length,
                        color=(((1 / self.n_food_vals) * self.agents[agent]),
                               1, 1),
                        s=228, marker='s')

        plt.axis("equal")
        plt.title(title, fontsize=10, fontweight='bold')
        plt.xlim([0, self.width])
        plt.ylim([0, self.height])
        plt.savefig(filename)


class Bot(object):
    """
    Simulates a Bot which moves around grid space, interacting with food
    objects.

    Parameters
    ----------
    width : int
        Width of grid space.
    height : int
        Height of grid space.
    n_bots : Optional[int]
        Number of bots. Default is 2.

    Attributes
    ----------
    width : int
        Width of grid space.
    height : int
        Height of grid space.
    n_bots : int
        Number of bots. Default is 2.
    agents : dict((int, int): race)
        A mapping of bot number i to current position.

    """
    def __init__(self, width, height, n_bots=2):
        self.width = width
        self.height = height
        self.n_bots = n_bots
        self.agents = {}

    def populate(self):
        """
        Populate the gridspace with agents, and updates `agents`.

        """
        # select random start location for each Bot
        all_cells = [Location(*i) for i in itertools.product(
            range(self.width), range(self.height))]
        print(all_cells)
        random.shuffle(all_cells)
        start_loc = all_cells[:self.n_bots]
        self.agents.update(dict(zip(start_loc, list(range(self.n_bots)))))

    def plot(self, title, filename):
        """
        Plot a figure and one subplot.

        Parameters
        ----------
        title : str
            The title of the plot.
        filename : str
            The location in which the plot will be saved.

        """
        for agent in self.agents:
            plt.scatter(agent.x + 0.5, agent.y + 0.5, color='r', marker='o')
        plt.title(title, fontsize=10, fontweight='bold')
        plt.xlim([0, self.width])
        plt.ylim([0, self.height])
        plt.xticks([])
        plt.yticks([])
        plt.savefig(filename)
        plt.show()


def main():
    food_1 = Food(50, 50, 0.3, 2, 100, 4)
    food_1.populate()
    food_1.plot('plot_1', 'plot_1.png')
    bot_1 = Bot(50, 50, 100)
    bot_1.populate()
    bot_1.plot('plot_1', 'plot_1.png')


if __name__ == "__main__":
    main()
